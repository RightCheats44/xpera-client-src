# BetterHurtCam — Buildable Source

Reconstructed from `betterhurtcam-1_9_11_mc1_21.jar` (already Fabric-remapped to yarn names).

## Build

```bash
gradle wrapper        # generate gradlew (once)
./gradlew build       # → build/libs/betterhurtcam-1.9.11.jar
```

Requires **JDK 21**.

## Project layout

```
src/main/java/net/uku3lig/betterhurtcam/
├── BetterHurtCam.java          ModInitializer, keybindings, config manager
├── UkulibIntegration.java      Hooks config screen into ukulib menu
├── config/
│   ├── BHCConfig.java          Serializable config POJO
│   ├── HurtCamType.java        Enum: OLD | YAW_BASED
│   └── ConfigScreen.java       In-game config screen (ukulib)
└── mixin/
    ├── MixinGameRenderer.java      Disable/scale/redirect hurtcam tilt
    ├── MixinInGameHud.java         Heart-blink toggle
    ├── MixinKeyboardHandler.java   Hidden key combos (B / J / M)
    └── MixinMinecraftClient.java   Keybinding tick handler + auto-attack
```

## Dependencies

| Dependency | Version |
|---|---|
| Minecraft | 1.21 |
| Fabric Loader | ≥ 0.13 |
| Fabric API | 0.100.3+1.21 |
| [ukulib](https://github.com/uku3lig/ukulib) | 1.0.0+1.21 |

## Credits

Original mod by **uku** — MIT License  
https://github.com/uku3lig/betterhurtcam
