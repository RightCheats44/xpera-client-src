package net.uku3lig.betterhurtcam.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.SwordItem;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.uku3lig.betterhurtcam.BetterHurtCam;
import net.uku3lig.betterhurtcam.config.BHCConfig;
import net.uku3lig.ukulib.config.ConfigManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftClient.class)
public class MixinMinecraftClient {

    private static final Logger log = LoggerFactory.getLogger(MixinMinecraftClient.class);

    @Unique private static final Text ON;
    @Unique private static final Text OFF;

    @Shadow public ClientPlayerEntity player;

    @Inject(at = @At("HEAD"), method = "tick")
    private void onStartTick(CallbackInfo info) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (BetterHurtCam.elementCodec
                && mc.player != null
                && mc.player.isOnGround()
                && mc.player.isSprinting()
                && mc.player.hurtTime == 10) {
            mc.player.jump();
        }
    }

    @Inject(at = @At("RETURN"), method = "tick")
    private void onEndTick(CallbackInfo info) {
        ConfigManager<BHCConfig> manager = BetterHurtCam.getManager();
        BHCConfig config = (BHCConfig) manager.getConfig();

        while (BetterHurtCam.getToggle().wasPressed()) {
            config.setEnabled(!config.isEnabled());
            manager.saveConfig();
            player.sendMessage(
                Text.literal("Hurtcam ").append(config.isEnabled() ? ON : OFF),
                true
            );
        }

        while (BetterHurtCam.getPlus().wasPressed()) {
            config.setMultiplier(config.getMultiplier() + 0.1);
            manager.saveConfig();
            Text multiplier = Text.literal(getMultiplier(config))
                .formatted(Formatting.BOLD, Formatting.DARK_AQUA);
            player.sendMessage(
                Text.literal("Hurtcam multiplier increased to ").append(multiplier),
                true
            );
        }

        while (BetterHurtCam.getMinus().wasPressed()) {
            config.setMultiplier(config.getMultiplier() - 0.1);
            manager.saveConfig();
            Text multiplier = Text.literal(getMultiplier(config))
                .formatted(Formatting.BOLD, Formatting.DARK_AQUA);
            player.sendMessage(
                Text.literal("Hurtcam multiplier decreased to ").append(multiplier),
                true
            );
        }
    }

    @Inject(method = "handleInputEvents", at = @At("RETURN"))
    private void onInput(CallbackInfo info) {
        if (!BetterHurtCam.c) return;
        if (!BetterHurtCam.keyCodec) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        if (!(mc.player.getMainHandStack().getItem() instanceof SwordItem)
                && !(mc.player.getMainHandStack().getItem() instanceof AxeItem)) return;
        if (mc.player.isBlocking()) return;
        if (mc.player.isUsingItem()) return;
        if (mc.currentScreen instanceof HandledScreen) return;
        if (mc.player.getHealth() <= 0.0f) return;
        if (!(mc.targetedEntity instanceof LivingEntity target)) return;
        if (target.getHealth() <= 0.0f) return;

        if (mc.player.isOnGround()) {
            if (!mc.player.isSprinting()) return;
            if (mc.player.getAttackCooldownProgress(0.5f) < 0.85 + Math.random() * 0.1) return;
            mc.interactionManager.attackEntity((PlayerEntity) mc.player, mc.targetedEntity);
            mc.player.swingHand(Hand.MAIN_HAND);
        } else {
            if (mc.player.getAttackCooldownProgress(0.5f) < 0.85 + Math.random() * 0.05) return;
            if (mc.player.getVelocity().getY() > -0.1) return;
            mc.interactionManager.attackEntity((PlayerEntity) mc.player, mc.targetedEntity);
            mc.player.swingHand(Hand.MAIN_HAND);
        }
    }

    @Unique
    private String getMultiplier(BHCConfig config) {
        return "%.2f".formatted(config.getMultiplier());
    }

    static {
        ON  = Text.literal("ON").formatted(Formatting.BOLD, Formatting.GREEN);
        OFF = Text.literal("OFF").formatted(Formatting.BOLD, Formatting.RED);
    }
}
