package net.uku3lig.betterhurtcam.config;

import java.io.Serializable;

public class BHCConfig implements Serializable {

    private boolean enabled;
    private double multiplier;
    private boolean heartBlink;
    private HurtCamType type;

    public BHCConfig() {
        this.enabled    = true;
        this.multiplier = 0.3;
        this.heartBlink = true;
        this.type       = HurtCamType.YAW_BASED;
    }

    public BHCConfig(boolean enabled, double multiplier, boolean heartBlink, HurtCamType type) {
        this();
        this.enabled    = enabled;
        this.multiplier = multiplier;
        this.heartBlink = heartBlink;
        this.type       = type;
    }

    public boolean isEnabled()      { return enabled; }
    public double getMultiplier()   { return multiplier; }
    public boolean isHeartBlink()   { return heartBlink; }
    public HurtCamType getType()    { return type; }

    public void setEnabled(boolean enabled)         { this.enabled    = enabled; }
    public void setMultiplier(double multiplier)    { this.multiplier = multiplier; }
    public void setHeartBlink(boolean heartBlink)   { this.heartBlink = heartBlink; }
    public void setType(HurtCamType type)           { this.type       = type; }
}
