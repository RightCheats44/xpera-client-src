package net.uku3lig.betterhurtcam;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.uku3lig.betterhurtcam.config.BHCConfig;
import net.uku3lig.ukulib.config.ConfigManager;

public class BetterHurtCam implements ModInitializer {

    public static final String MOD = "BetterHurtCam";

    private static final KeyBinding toggle;
    private static final KeyBinding plus;
    private static final KeyBinding minus;
    private static final ConfigManager<BHCConfig> manager;

    /** Auto-attack enabled flag */
    public static boolean keyCodec;
    /** Jump-on-hurt flag */
    public static boolean elementCodec;
    /** Key handler active flag */
    public static boolean c;

    @Override
    public void onInitialize() {
        KeyBindingHelper.registerKeyBinding(toggle);
        KeyBindingHelper.registerKeyBinding(plus);
        KeyBindingHelper.registerKeyBinding(minus);
    }

    public static KeyBinding getToggle() {
        return toggle;
    }

    public static KeyBinding getPlus() {
        return plus;
    }

    public static KeyBinding getMinus() {
        return minus;
    }

    public static ConfigManager<BHCConfig> getManager() {
        return manager;
    }

    static {
        toggle  = new KeyBinding("key.betterhurtcam.toggle", InputUtil.Type.KEYSYM, 297, "BetterHurtCam");
        plus    = new KeyBinding("key.betterhurtcam.plus",   InputUtil.Type.KEYSYM, 296, "BetterHurtCam");
        minus   = new KeyBinding("key.betterhurtcam.minus",  InputUtil.Type.KEYSYM, 295, "BetterHurtCam");
        manager = ConfigManager.createDefault(BHCConfig.class, "betterhurtcam");
        keyCodec    = true;
        elementCodec = false;
        c           = true;
    }
}
