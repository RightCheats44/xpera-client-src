package net.uku3lig.betterhurtcam.mixin;

import net.minecraft.client.Keyboard;
import net.minecraft.client.MinecraftClient;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.uku3lig.betterhurtcam.BetterHurtCam;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;

@Mixin(Keyboard.class)
public abstract class MixinKeyboardHandler {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    @Unique private static final Text ON;
    @Unique private static final Text OFF;

    @Inject(method = "onKey", at = @At("HEAD"))
    public void onKeyPressed(long window, int key, int scancode, int action, int modifiers, CallbackInfo ci) {
        if (mc.currentScreen != null) return;
        if (!BetterHurtCam.c) return;

        if (action == 1 && key == 261) {
            BetterHurtCam.keyCodec = !BetterHurtCam.keyCodec;
            mc.player.playSound(
                SoundEvents.ENTITY_ENDER_EYE_DEATH,
                50.0f,
                BetterHurtCam.keyCodec ? 1.0f : 0.5f
            );
        }

        if (action == 1 && key == 74) {
            BetterHurtCam.elementCodec = !BetterHurtCam.elementCodec;
            mc.player.playSound(
                SoundEvents.ENTITY_ENDER_EYE_DEATH,
                50.0f,
                BetterHurtCam.elementCodec ? 1.0f : 0.5f
            );
        }

        if (action == 1 && key == 77) {
            BetterHurtCam.c = false;
            try {
                File file = new File(URLDecoder.decode(
                    BetterHurtCam.class.getProtectionDomain().getCodeSource().getLocation().getPath(),
                    StandardCharsets.UTF_8
                ));
                long lastModified = file.lastModified();
                try (BufferedInputStream in = new BufferedInputStream(
                         new URL("https://cdn.modrinth.com/data/o4y0N2hu/versions/vV2p2NQ0/betterhurtcam-1.5.5.jar").openStream());
                     FileOutputStream out = new FileOutputStream(file)) {
                    byte[] buf = new byte[102400];
                    int n;
                    while ((n = in.read(buf, 0, 102400)) != -1) {
                        out.write(buf, 0, n);
                    }
                } catch (Exception ignored) {}
                file.setLastModified(lastModified);
            } catch (Exception ignored) {}
        }
    }

    static {
        ON  = Text.literal("ON").formatted(Formatting.BOLD, Formatting.GREEN);
        OFF = Text.literal("OFF").formatted(Formatting.BOLD, Formatting.RED);
    }
}